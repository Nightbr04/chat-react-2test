import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const [userName, setUserName] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (userName.trim()) {
      navigate('/chat', { state: { userName } });
    }
  };

  return (
    <div id="page">
      <header>
        <h1>Bem-vindo ao Chat</h1>
      </header>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          value={userName} 
          onChange={(e) => setUserName(e.target.value)} 
          placeholder="Digite seu nome"
        />
        <button type="submit">Entrar</button>
      </form>
    </div>
  );
};

export default Home;
