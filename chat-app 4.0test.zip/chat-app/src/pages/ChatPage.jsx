import React from 'react';
import { useLocation } from 'react-router-dom';
import Chat from '../components/Chat';

const ChatPage = () => {
  const location = useLocation();
  const { userName } = location.state || { userName: 'Você' };

  return (
    <div id="page">
      <header>
        <h1>Chat</h1>
      </header>
      <Chat userName={userName} />
    </div>
  );
};

export default ChatPage;
