import React, { useState, useEffect, useRef } from 'react';
import '../Chat.css';

const Chat = ({ userName }) => {
  const [messages, setMessages] = useState([
    { user: 'Atendente', text: 'Olá Sr. baks' },
    { user: 'Atendente', text: 'Bla bla bla bla?' },
    { user: 'Você', text: 'Blaaaa Bla' },
    { user: 'Você', text: 'Bla bla Boi' },
    { user: 'Atendente', text: 'KKKKKKKKKKK blaboi?' },
    { user: 'Atendente', text: 'Bla Blabomb' }
  ]);

  const [message, setMessage] = useState('');
  const messagesEndRef = useRef(null);

  const sendMessage = () => {
    if (message.trim() !== '') {
      setMessages([...messages, { user: userName || 'Você', text: message }]);
      setMessage('');
    }
  };

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  return (
    <div id="page">
      <div className="messages-list">
        {messages.map((msg, index) => (
          <div className={`message-item ${msg.user === (userName || 'Você') ? 'message-user' : ''}`} key={index}>
            <div className="msg-user"><strong>{msg.user} diz:</strong></div>
            <div className="msg-chat">{msg.text}</div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <form id="form-chat-send" onSubmit={(e) => { e.preventDefault(); sendMessage(); }}>
        <input 
          type="text" 
          id="messageInput" 
          value={message} 
          onChange={(e) => setMessage(e.target.value)} 
        />
        <button type="button" onClick={sendMessage}>ENVIAR</button>
      </form>
    </div>
  );
};

export default Chat;
